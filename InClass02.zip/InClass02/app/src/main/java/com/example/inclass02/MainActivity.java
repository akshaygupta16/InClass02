package com.example.inclass02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView tv_shapelabel;
    private TextView tv_area;
    private Button bt_calcuate;
    private Button bt_clear;
    private ImageView img_cir;
    private ImageView img_sq;
    private ImageView img_tri;
    private EditText et_l1;
    private EditText et_l2;
    private int selectedShape;
    float length1;
    float length2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Area Calculator");

        et_l1= findViewById(R.id.et_l1);
        et_l2= findViewById(R.id.et_l2);
        tv_area= findViewById(R.id.tv_area);
        tv_shapelabel= findViewById(R.id.tv_shapelabel);
        bt_calcuate= findViewById(R.id.bt_calculate);
        bt_clear= findViewById(R.id.bt_clear);
        img_cir= findViewById(R.id.img_cir);
        img_sq= findViewById(R.id.img_sq);
        img_tri= findViewById(R.id.img_tri);

        //clearButton();


        String templ1 = et_l1.getText().toString();
        String templ2 = et_l2.getText().toString();

        if(templ1!=null && !templ1.equals(""))
            length1 = Float.parseFloat(et_l1.getText().toString());

        if(templ2!=null && !templ2.equals(""))
            length2 = Float.parseFloat(et_l2.getText().toString());


        bt_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearButton();
            }
        });

        img_tri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectedShape=1;
                tv_shapelabel.setText("Triangle");

                et_l1.setVisibility(View.VISIBLE);
                et_l2.setVisibility(View.VISIBLE);
            }
        });

        img_sq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectedShape=2;
                tv_shapelabel.setText("Square");

                et_l1.setVisibility(View.VISIBLE);
                et_l2.setVisibility(View.INVISIBLE);
            }
        });

        img_cir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectedShape=3;
                tv_shapelabel.setText("Circle");

                et_l1.setVisibility(View.VISIBLE);
                et_l2.setVisibility(View.INVISIBLE);
            }
        });

        bt_calcuate.setOnClickListener(new View.OnClickListener() {


            @Override

            public void onClick(View view) {
//                length1 = Float.parseFloat(et_l1.getText().toString());
//                length2 = Float.parseFloat(et_l2.getText().toString());
                if(et_l1.getText().toString().equals("")){
                    et_l1.setError("Hey I need a value");
                }
                if(et_l2.getText().toString().equals("")){
                    et_l2.setError("Hey I need a value");
                }
                switch (selectedShape){
                    case 1:
                        //float area =length1*length2;
                        tv_area.setText("trex");
                    case 2:
                        //double area1= (double) (length1*length1);
                        tv_area.setText("sqr");
//                    case 3:
//                        //float area2= (float) (3.14*length1*length1);
//                        tv_area.setText("cir");
                }
            }
        });


    }

    public void clearButton(){

        et_l1.setVisibility(View.VISIBLE);
        et_l2.setVisibility(View.VISIBLE);
        et_l1.setText("");
        et_l2.setText("");

        tv_shapelabel.setText("Select a Shape");
        tv_area.setText("");
        selectedShape=0;
    }
}
